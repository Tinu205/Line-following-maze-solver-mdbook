from controller import Supervisor # type: ignore

import sys
import json
import math

from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP
from zipfile import ZipFile


pi=math.pi
MAX_TIME = 180
tolerance = 0.06
FONT_SIZE = 0.08




class Supervisor_Controller:
    def __init__(self, supervisor):
        print("Initializing Supervisor Controller!")
        self.supervisor = supervisor
        self.remaining_time = MAX_TIME
        self.waypoints_reached = 0
        self.run_completed = False
        self.robot_position_time=[]
        self.waypoints = []

        self.get_robot_fields()
        self.get_waypoint_fields()
        self.get_team_info()
        self.init_waypoints()

        self.update_waypoint(self.waypoints.pop(0))



    def get_team_info(self):
        self.team_info = {} #This would store team info, primarily the team ID after reading it from the JSON file
        try:
            with open('../../teaminfo.json') as team_file:
                self.team_info = json.load(team_file) #Read team information from the file and store it
        except:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            raise Exception("File not found, please make sure teaminfo.json exists in the parent folder") from None

        self.team_id = self.team_info['team_id'] #Extract the team ID
        print("Team ID:",self.team_id)
        if self.team_id == "IE#1234":
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write("Please first edit the teaminfo.json file and enter your team ID in place of IE#1234\n")
            sys.exit(1)

    def get_waypoint_fields(self):
        self.waypoint = self.supervisor.getFromDef("waypoint")

        if self.waypoint is None:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write(f"Error: DEF waypoint not found.\n")
            sys.exit(1)

        self.translation_field_waypoint = self.waypoint.getField("translation")

    def get_robot_fields(self):
        self.robot = self.supervisor.getFromDef("my-e-puck")

        if self.robot is None:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write(f"Error: DEF my-e-puck not found.\n")
            sys.exit(1)

        self.translation_field_robot = self.robot.getField("translation")
    
    def update_remaining_time(self,time) -> float:
        self.remaining_time = MAX_TIME-time
        return self.remaining_time
    
    def check_remaining_time(self) -> bool:
        if self.remaining_time<=0:
            return True
        else:
            return False
        
    def update_robot_location(self) -> list:
        self.robot_location = self.robot.getField("translation").getSFVec3f()
        return self.robot_location
    
    def update_waypoint(self, new_position) -> list:
        self.translation_field_waypoint.setSFVec3f(new_position)
        self.waypoint_location=new_position
        return self.waypoint_location 

    def check_waypoint_reached(self) -> bool:
        if self.robot_location[0]>self.waypoint_location[0]-tolerance and self.robot_location[0]<self.waypoint_location[0]+tolerance and self.robot_location[1]>self.waypoint_location[1]-tolerance and self.robot_location[1]<self.waypoint_location[1]+tolerance: 
            self.waypoints_reached += 1
            return True
        else:
            return False
        
    def check_collision(self) -> bool:
        ContactPoints = self.robot.getContactPoints()

        for x in ContactPoints:
            if x.point[2] > 0.02 :
                return True
        return False
    
    def save_coordinates_file(self,data):
        with open("coordinates.bin", "wb") as myfile: #First, we'll open the coordinates file
            public_key = RSA.import_key(open("public.pem").read()) #Reading the public RSA Key
            temp_aes_key = get_random_bytes(16) #Actual data would be encrypted with AES because RSA is slow, so we generate a random AES key
            # Encrypt the session key with the public RSA key
            cipher_rsa = PKCS1_OAEP.new(public_key) #Initialize the PKCS Cipher Suit using OAEP Padding mechanism
            enc_session_key = cipher_rsa.encrypt(temp_aes_key) #Encrypt the temporary AES key with RSA instead of the actual data
            # Encrypt the data with the AES session key
            cipher_aes = AES.new(temp_aes_key, AES.MODE_EAX) #Initialize the AES Cipher
            ciphertext, tag = cipher_aes.encrypt_and_digest(json.dumps(data).encode('utf8')) #Encrypt UTF 8 encoded sringified JSON with AES
            [ myfile.write(x) for x in (enc_session_key, cipher_aes.nonce, tag, ciphertext) ] #Write the data into the file   


    def save_zip_file(self):
        with ZipFile("../../"+self.team_id+"_Task5B"+".zip",'w') as myzip: #Create the zip file
            myzip.write('coordinates.bin') #Add the coordinates file
            myzip.write('../e-puck/e-puck.py','e-puck.py') #Add the student's controller code
            myzip.write('../../teaminfo.json','team_info.json') #Add the team_info file
            print("Zipping!")

    def update_robot_info(self, LABEL_ID):
        time_text = f"{self.remaining_time:5.1f} s"

        display_message = (
            f"Remaining time: {time_text}   "
            f"Waypoints reached: {self.waypoints_reached}"
        )

        self.supervisor.setLabel(LABEL_ID, display_message, 0.01, 0.01, FONT_SIZE, 0x000000, 0.0, "Verdana")

    def update_final_info(self):
        display_message = (
            f"All waypoints reached!"
        )
        self.supervisor.setLabel(2, display_message, 0.01, 0.06, FONT_SIZE, 0x006400, 0.0, "Verdana")


    def generate_straight_waypoints(self, starting_x, starting_y, ending_x, ending_y, z_offset, number_of_waypoints):
        temp_list = []
        for i in range(number_of_waypoints):
            temp_list.append([starting_x + i * (ending_x - starting_x) / number_of_waypoints,
                            starting_y + i * (ending_y - starting_y) / number_of_waypoints, z_offset])
        return temp_list


    def generate_circular_waypoints(
        self, starting_angle, ending_angle, number_of_waypoints,
        center_x, center_y, radius, z_offset, clockwise=False
    ):
        temp_list = []
        angle_range = ending_angle - starting_angle
        multiplier = -1 if clockwise else 1

        for i in range(number_of_waypoints):
            angle = starting_angle + multiplier * angle_range * i / (number_of_waypoints - 1)
            x = radius * math.cos(angle) + center_x
            y = radius * math.sin(angle) + center_y
            temp_list.append([x, y, z_offset])

        return temp_list

    
    def init_waypoints(self) -> list:
        self.waypoints += self.generate_straight_waypoints(starting_x=-0.9,starting_y= -0.55,ending_x=-0.40,ending_y=-0.55,z_offset=0.03,number_of_waypoints=5)
        self.waypoints += self.generate_circular_waypoints(starting_angle=-pi/2,ending_angle=pi/2,number_of_waypoints=5,center_x=-0.40,center_y=-0.35,radius=0.2,z_offset=0.03)
        self.waypoints += self.generate_straight_waypoints(starting_x=-0.40,starting_y= -0.15,ending_x=-0.60,ending_y=-0.15,z_offset=0.03,number_of_waypoints=3)
        self.waypoints += self.generate_circular_waypoints(starting_angle=-pi/2,ending_angle=pi/2,number_of_waypoints=5,center_x=-0.60,center_y=0.05,radius=0.2,z_offset=0.03,clockwise=True)
        self.waypoints += self.generate_straight_waypoints(starting_x=-0.60,starting_y= 0.25,ending_x=-0.50,ending_y=0.25,z_offset=0.03,number_of_waypoints=1)
        self.waypoints += self.generate_circular_waypoints(starting_angle=-pi/2,ending_angle=0,number_of_waypoints=3,center_x=-0.50,center_y=0.40,radius=0.15,z_offset=0.03)
        self.waypoints += self.generate_straight_waypoints(starting_x=-0.35,starting_y= 0.40,ending_x=-0.35,ending_y=0.60,z_offset=0.03,number_of_waypoints=1)
        self.waypoints += self.generate_circular_waypoints(starting_angle=pi,ending_angle=pi/2,number_of_waypoints=3,center_x=-0.20,center_y=0.60,radius=0.15,z_offset=0.03)
        self.waypoints += self.generate_straight_waypoints(starting_x=-0.20,starting_y= 0.75,ending_x=0.40,ending_y=0.75,z_offset=0.03,number_of_waypoints=4)
        self.waypoints += self.generate_circular_waypoints(starting_angle=pi/2,ending_angle=-pi/2,number_of_waypoints=5,center_x=0.40,center_y=0.45,radius=0.30,z_offset=0.03)
        self.waypoints += self.generate_circular_waypoints(starting_angle=pi/2,ending_angle=-pi/2,number_of_waypoints=4,center_x=0.30,center_y=-0.05,radius=0.20,z_offset=0.03,clockwise=True)
        self.waypoints += self.generate_straight_waypoints(starting_x=0.30,starting_y= -0.25,ending_x=0.50,ending_y=-0.25,z_offset=0.03,number_of_waypoints=1)
        self.waypoints += self.generate_circular_waypoints(starting_angle=pi/2,ending_angle=0,number_of_waypoints=3,center_x=0.50,center_y=-0.40,radius=0.15,z_offset=0.03)
        self.waypoints += self.generate_straight_waypoints(starting_x=0.65,starting_y= -0.40,ending_x=0.65,ending_y=-0.60,z_offset=0.03,number_of_waypoints=2)
        self.waypoints += self.generate_circular_waypoints(starting_angle=pi,ending_angle=pi/2,number_of_waypoints=3,center_x=0.80,center_y=-0.60,radius=0.15,z_offset=0.03,clockwise=True )
        self.waypoints += self.generate_straight_waypoints(starting_x=0.80,starting_y= -0.75,ending_x=1.30,ending_y=-0.75,z_offset=0.03,number_of_waypoints=2)

        print(len(self.waypoints))
        # self.waypoints.reverse()
        return self.waypoints

    def check_and_update(self):

        if not self.run_completed:
            self.robot_position_time.append([self.update_robot_location(), self.update_remaining_time(self.supervisor.getTime())])
            self.update_robot_info(LABEL_ID=1)

            if self.check_collision():
                self.update_remaining_time(MAX_TIME)  # Reset remaining time on collision
                print("Collision detected!!!")
                self.run_completed = True

            if self.check_remaining_time():
                print("Time is up!!!")
                self.run_completed = True
            
            if self.check_waypoint_reached():
                if self.waypoints:
                    self.update_waypoint(self.waypoints.pop(0))
                else:
                    self.update_robot_info(LABEL_ID=1)
                    self.update_final_info()
                    print("All waypoints reached!!!")
                    self.run_completed = True
                
        else:
            self.save_coordinates_file(self.robot_position_time)
            self.save_zip_file()
            return False
                
        return True



