from controller import Robot, DistanceSensor, Motor
# import numpy as np

#-------------------------------------------------------
# Initialize variables

TIME_STEP = 64
MAX_SPEED = 6.28

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())   # [ms]

#-------------------------------------------------------
# Initialize devices

# ground sensors
gs = []
gsNames = ['gs0', 'gs1', 'gs2'] # Left Middle Right
for i in range(3):
    gs.append(robot.getDevice(gsNames[i]))
    gs[i].enable(timestep)

# motors    
leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)


#-------------------------------------------------------
# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    # Update sensor readings

    gsValues = []
    for i in range(3):
        gsValues.append(gs[i].getValue())
    print(gsValues)
    
    set_point = 0
    
    error = set_point - (gsValues[2] - gsValues[0])
    print(error) 
    if error < 0:
        leftSpeed = (0.75*MAX_SPEED)
        rightSpeed = 0
    elif error > 0:
        leftSpeed = 0
        rightSpeed = (0.75*MAX_SPEED)
    else:
        leftSpeed = MAX_SPEED
        rightSpeed = MAX_SPEED
        
    leftMotor.setVelocity(leftSpeed)
    rightMotor.setVelocity(rightSpeed)
    