# my_supervisor_controller.py

from controller import Supervisor # type: ignore 
from supervisor_module import Supervisor_Controller

supervisor = Supervisor()
controller = Supervisor_Controller(supervisor)

timestep = int(supervisor.getBasicTimeStep())

while supervisor.step(timestep) != -1:
    if not controller.check_and_update():
        break

supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
