from controller import Supervisor, Robot # type: ignore
import json
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP
from zipfile import ZipFile
import random
import math
import sys

pi=math.pi
MAX_TIME = 180
tolerance = 0.07
FONT_SIZE = 0.08

class Supervisor_Controller:
    def __init__(self, supervisor):
        print("Initializing Supervisor Controller!")
        self.supervisor = supervisor
        self.remaining_time = MAX_TIME
        self.progress = 0
        self.run_completed = False
        self.box_randomize = False
        self.coordinates = {'robot_position_time': [], 'box_position': []}

        self.get_robot_fields()
        self.get_team_info()
        self.get_box_positions()

    def get_robot_fields(self):
        self.robot = self.supervisor.getFromDef("my-e-puck")

        if self.robot is None:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write(f"Error: DEF my-e-puck not found.\n")
            sys.exit(1)

        self.translation_field_robot = self.robot.getField("translation")
    
    def get_team_info(self):
        self.team_info = {} #This would store team info, primarily the team ID after reading it from the JSON file
        try:
            with open('../../teaminfo.json') as team_file:
                self.team_info = json.load(team_file) #Read team information from the file and store it
        except:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            raise Exception("File not found, please make sure teaminfo.json exists in the parent folder") from None

        self.team_id = self.team_info['team_id'] #Extract the team ID
        print("Team ID:",self.team_id)
        if self.team_id == "IE#1234":
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write("Please first edit the teaminfo.json file and enter your team ID in place of IE#1234\n")
            sys.exit(1)

    def get_box_positions(self):
        self.cubeObstaclesGroup = self.supervisor.getFromDef("BoxGroup")

        if self.cubeObstaclesGroup is None:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write(f"Error: DEF BoxGroup not found.\n")
            sys.exit(1)

        self.cubeObstaclesField = self.cubeObstaclesGroup.getField("children")
        self.cubeObstaclesCount = self.cubeObstaclesField.getCount()
        self.cubeObstacles = [self.cubeObstaclesField.getMFNode(x) for x in range(self.cubeObstaclesCount)]

    def normalize(self, vector):
        length = math.sqrt(vector[0] ** 2 + vector[1] ** 2 + vector[2] ** 2)
        if length == 0:
            return [0, 1, 0]
        return [vector[i] / length for i in range(3)]

    def randomly_place_object(self, node):
        translationField = node.getField("translation")
        rotationField = node.getField("rotation")

        newPosition = [random.uniform(-0.8, 0.8), random.uniform(-1.2, 1.2), random.uniform(0.1, 0.5)]
        newRotation = self.normalize([random.random(), random.random(), random.random()]) + [random.random() * math.pi * 2]

        translationField.setSFVec3f(newPosition)
        rotationField.setSFRotation(newRotation)
  
    def check_collision(self) -> bool:
        ContactPoints = self.robot.getContactPoints()

        for x in ContactPoints:
            if x.point[2] > 0.02 :
                return True
        return False
    
    def update_remaining_time(self,time) -> float:
        self.remaining_time = MAX_TIME-time
        return self.remaining_time
    
    def check_remaining_time(self) -> bool:
        if self.remaining_time<=0:
            return True
        else:
            return False
        
    def update_robot_location(self) -> list:
        self.robot_location = self.robot.getField("translation").getSFVec3f()
        return self.robot_location
    
    def update_robot_info(self, LABEL_ID):
        time_text = f"{self.remaining_time:5.1f} s"

        display_message = (
            f"Remaining time: {time_text}   "
            f"Progress: {self.progress:.0f}%"
        )

        self.supervisor.setLabel(LABEL_ID, display_message, 0.01, 0.01, FONT_SIZE, 0x000000, 0.0, "Verdana")

    def update_final_info(self):
        display_message = (
            f"Goal reached!"
        )
        self.supervisor.setLabel(2, display_message, 0.01, 0.06, FONT_SIZE, 0x006400, 0.0, "Verdana")    
    
    def save_box_coordinates(self):
        for cube in self.cubeObstacles:
            translationField = cube.getField("translation")
            rotationField = cube.getField("rotation")
            translation = translationField.getSFVec3f()
            rotation = rotationField.getSFRotation()
            self.coordinates['box_position'].append([translation, rotation])

    def save_coordinates_file(self,data):
        with open("coordinates.bin", "wb") as myfile:
            public_key = RSA.import_key(open("public.pem").read())
            temp_aes_key = get_random_bytes(16)
            cipher_rsa = PKCS1_OAEP.new(public_key)
            enc_session_key = cipher_rsa.encrypt(temp_aes_key)
            cipher_aes = AES.new(temp_aes_key, AES.MODE_EAX)
            ciphertext, tag = cipher_aes.encrypt_and_digest(json.dumps(data).encode('utf8'))
            [myfile.write(x) for x in (enc_session_key, cipher_aes.nonce, tag, ciphertext)]

    def save_zip_file(self):
        with ZipFile("../../"+self.team_id+"_Task3"+".zip",'w') as myzip: #Create the zip file
            myzip.write('coordinates.bin') #Add the coordinates file
            myzip.write('../e-puck/e-puck.py','e-puck.py') #Add the student's controller code
            myzip.write('../../teaminfo.json','team_info.json') #Add the team_info file
            print("Zipping!")

    def check_and_update(self):

        if not self.run_completed:

            if not self.box_randomize:
                for i in range(self.cubeObstaclesCount):
                    self.randomly_place_object(self.cubeObstacles[i])

                self.save_box_coordinates()
                self.box_randomize = True
            
            self.coordinates['robot_position_time'].append([self.update_robot_location(), 
                                             self.update_remaining_time(self.supervisor.getTime())])

            self.progress = (abs(self.translation_field_robot.getSFVec3f()[1] + 1.5) / 3.7) * 100
            self.update_robot_info(LABEL_ID=1)

            if self.check_collision():
                # self.update_remaining_time(MAX_TIME)  # Reset remaining time on collision
                print("Collision detected!!!")
                self.run_completed = True

            if self.check_remaining_time():
                print("Time is up!!!")
                self.run_completed = True
            
            if self.progress >= 100:
                print("Goal Reached!!!")
                self.update_final_info()
                self.run_completed = True

        else:
            self.save_coordinates_file(self.coordinates)
            self.save_zip_file()
            return False
        
        return True