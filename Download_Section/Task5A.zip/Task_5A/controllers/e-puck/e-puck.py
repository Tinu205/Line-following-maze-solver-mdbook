'''
**********************************************************************************************************
*
*        		======================================================
*           	e-Yantra School Robotics Competition (eYSRC 2025-2026)
*        		======================================================
*
*  This script is to be used to implement Competition Task titled- 'Line Follower: Bang-Bang Controller'.
*
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*
*  e-Yantra - A MOE project under National Mission on Education using ICT (NMEICT)
*
***********************************************************************************************************
'''

# Team ID:
# 					[ Team-ID ]
# Author List:
# 					[ Names of team members worked on this file separated by Comma: Name1, Name2, ... ]
# Filename:         e-puck.py
# Functions:
#                   [ Comma separated list of functions in this file ]
# Global variables:
# 					[ List of global variables defined in this file ]

from controller import Robot

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())


# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    # Read the sensors:
    # Enter here functions to read sensor data, like:

    # Process sensor data here.

    # Enter here functions to send actuator commands, like:
    pass

# Enter here exit cleanup code.
