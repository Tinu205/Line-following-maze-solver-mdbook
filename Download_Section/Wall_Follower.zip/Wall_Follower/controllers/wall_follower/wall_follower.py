'''
*********************************************************************************************
*
*                =========================================================
*               e-Yantra School Robotics Competition (eYSRC 2025 - 2026)
*                =========================================================
*
*  This script is to be used to implement Competition Task 3 (Wall following) assignment titled:
*  'Wall Follower using Bang Bang Controller'
*
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*
*  e-Yantra - A MOE project under National Mission on Education using ICT (NMEICT)
*
*********************************************************************************************
'''
from controller import Robot

# -------------------- Constants --------------------
TIMESTEP = 32
MAX_SPEED = 6.0

# -------------------- Robot Instance --------------------
robot = Robot()

# -------------------- Motors --------------------
#Get the Left and Right Motors


# Configure motors for velocity control


# -------------------- Sensor --------------------
ps1 = robot.getDevice('ps1')

# Enable the sensor


# Get simulation timestep
timestep = int(robot.getBasicTimeStep())

# -------------------- Main Loop --------------------
while robot.step(timestep) != -1:

    # Read proximity sensor value

    # Convert sensor reading to distance

    # Define desired wall distance

    # Compute error from desired distance

    # Decide motor speeds based on error

    # Set motor velocities
    pass
# End of controller
