'''
*********************************************************************************************
*
*                =========================================================
*               e-Yantra School Robotics Competition (eYSRC 2025 - 2026)
*                =========================================================
*
*  This script is to be used to implement Competition Task 3 (Obstacle Avoidance) assignment titled:
*  'Obstacle Avoidance using Proximity Sensor.'
*
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*
*  e-Yantra - A MOE project under National Mission on Education using ICT (NMEICT)
*
*********************************************************************************************
'''

from controller import Robot

# -------------------- Robot Instance --------------------
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# -------------------- Constants --------------------
MAX_SPEED = 6.28
w = 0.75 * MAX_SPEED

# -------------------- Motors --------------------
leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')

# Configure motors for velocity control


# -------------------- Proximity Sensors --------------------
psNames = [
    'ps0', 'ps1', 'ps2', 'ps3',
    'ps4', 'ps5', 'ps6', 'ps7'
]

ps = []
for i in range(8):
    # Get and enable proximity sensors
    # ps.append(robot.getDevice(psNames[i]))
    # ps[i].enable(timestep)
    pass

# -------------------- Motion Functions --------------------
def go_straight(w):
    # Set both wheels to move forward
    pass


def soft_right(w, t):
    # Turn robot slightly to the right
    pass


def soft_left(w, t):
    # Turn robot slightly to the left
    pass


# -------------------- Main Loop --------------------
while robot.step(timestep) != -1:

    # Read all proximity sensor values

    # Decide direction based on sensor readings

    # Call appropriate motion function

# End of controller
