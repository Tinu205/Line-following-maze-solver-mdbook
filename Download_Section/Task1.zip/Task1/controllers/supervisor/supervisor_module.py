from controller import Supervisor
import sys
import json
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP
from zipfile import ZipFile



MAX_TIME = 180
tolerance = 0.09
FONT_SIZE = 0.06



radish_pos = [0.9, 0.5, 0.03]
pumpkin_pos = [0.0, 0.0, 0.03]
carrot_pos = [0.9, -0.5, 0.03]
radish_drop_pos = [0.0, -0.5, 0.02]
pumpkin_drop_pos = [-0.9, 0.0, 0.02]
carrot_drop_pos = [0.0, 0.5, 0.02]

waypoints_sequence = [["radish",radish_pos, radish_drop_pos],
                     ["pumpkin",pumpkin_pos, pumpkin_drop_pos],
                     ["carrot",carrot_pos, carrot_drop_pos]]


class Supervisor_Controller:
    def __init__(self, supervisor):
        print("Initializing Supervisor Controller!")
        self.supervisor = supervisor
        self.remaining_time = MAX_TIME
        self.run_completed = False
        self.robot_position_time=[]
        self.status = "pick"
        self.message = ""
        self.collected = {"carrot": 0, "pumpkin": 0, "radish": 0}
        self.dropped = {"carrot": 0, "pumpkin": 0, "radish": 0}

        self.get_team_info()

        # Get waypoint nodes
        self.radish_waypoint = self.get_waypoint_node("radish_waypoint")
        self.pumpkin_waypoint = self.get_waypoint_node("pumpkin_waypoint")
        self.carrot_waypoint = self.get_waypoint_node("carrot_waypoint")
        self.drop_waypoint = self.get_waypoint_node("drop_waypoint")

        # Get robot node
        self.robot = self.get_robot_node("my-e-puck")    
        self.waypoint = waypoints_sequence.pop(0)



    def get_team_info(self):
        self.team_info = {} #This would store team info, primarily the team ID after reading it from the JSON file
        try:
            with open('../../teaminfo.json') as team_file:
                self.team_info = json.load(team_file) #Read team information from the file and store it
        except:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            raise Exception("File not found, please make sure teaminfo.json exists in the parent folder") from None

        self.team_id = self.team_info['team_id'] #Extract the team ID
        print("Team ID:",self.team_id)
        if self.team_id == "IE#1234":
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write("Please first edit the teaminfo.json file and enter your team ID in place of IE#1234.\n")
            sys.exit(1)

    def get_waypoint_node(self, def_name):
        node = self.supervisor.getFromDef(def_name)
        if node is None:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write(f"Error: DEF '{def_name}' not found.\n")
            sys.exit(1)
        return node

    def get_robot_node(self, def_name):
        node = self.supervisor.getFromDef(def_name)
        if node is None:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write(f"Error: DEF '{def_name}' not found.\n")
            sys.exit(1)
        return node
    
    def update_remaining_time(self,time) -> float:
        self.remaining_time = MAX_TIME-time
        return self.remaining_time
    
    def check_remaining_time(self) -> bool:
        if self.remaining_time<=0:
            return True
        else:
            return False
        
    def update_robot_location(self) -> list:
        self.robot_location = self.robot.getField("translation").getSFVec3f()
        return self.robot_location

    def check_waypoint_reached(self, waypoint_location) -> bool:
        if self.robot_location[0]>waypoint_location[0]-tolerance and self.robot_location[0]<waypoint_location[0]+tolerance and self.robot_location[1]>waypoint_location[1]-tolerance and self.robot_location[1]<waypoint_location[1]+tolerance: 
            return True
        else:
            return False

    def check_collision(self) -> bool:
        ContactPoints = self.robot.getContactPoints()

        for x in ContactPoints:
            if x.point[2] > 0.02 :
                self.error_message = "Faile"
                # self.error_message = "Collision Detected !!!"
                print("Collision detected!!!")
                return True
        return False
    
    def save_coordinates_file(self,data):
        with open("coordinates.bin", "wb") as myfile: #First, we'll open the coordinates file
            public_key = RSA.import_key(open("public.pem").read()) #Reading the public RSA Key
            temp_aes_key = get_random_bytes(16) #Actual data would be encrypted with AES because RSA is slow, so we generate a random AES key
            # Encrypt the session key with the public RSA key
            cipher_rsa = PKCS1_OAEP.new(public_key) #Initialize the PKCS Cipher Suit using OAEP Padding mechanism
            enc_session_key = cipher_rsa.encrypt(temp_aes_key) #Encrypt the temporary AES key with RSA instead of the actual data
            # Encrypt the data with the AES session key
            cipher_aes = AES.new(temp_aes_key, AES.MODE_EAX) #Initialize the AES Cipher
            ciphertext, tag = cipher_aes.encrypt_and_digest(json.dumps(data).encode('utf8')) #Encrypt UTF 8 encoded sringified JSON with AES
            [ myfile.write(x) for x in (enc_session_key, cipher_aes.nonce, tag, ciphertext) ] #Write the data into the file   


    def save_zip_file(self):
        with ZipFile("../../"+self.team_id+"_Task1"+".zip",'w') as myzip: #Create the zip file
            myzip.write('coordinates.bin') #Add the coordinates file
            myzip.write('../e-puck/e-puck.py','e-puck.py') #Add the student's controller code
            myzip.write('../../teaminfo.json','team_info.json') #Add the team_info file
            print("Zipping!")

    def update_robot_info(self, LABEL_ID):
        time_text = f"{self.remaining_time:5.1f} s"

        display_message = (
            f"Remaining time: {time_text}\n\n"
            f"Radish    - Collected: {self.collected['radish']}, Dropped: {self.dropped['radish']}\n"
            f"Pumpkin   - Collected: {self.collected['pumpkin']}, Dropped: {self.dropped['pumpkin']}\n"
            f"Carrot    - Collected: {self.collected['carrot']}, Dropped: {self.dropped['carrot']}\n"
        )

        self.supervisor.setLabel(LABEL_ID, display_message, 0.01, 0.01, FONT_SIZE, 0x000000, 0.0, "Verdana")

    def check_and_update(self):

        if not self.run_completed:
            self.robot_position_time.append([self.update_robot_location(), self.update_remaining_time(self.supervisor.getTime())])
            self.update_robot_info(LABEL_ID=1)

            if self.check_collision():
                self.update_remaining_time(MAX_TIME)  # Reset remaining time on collision
                self.run_completed = True

            if self.check_remaining_time():
                print("Time is up!")
                self.run_completed = True

                
            if self.status == "pick":
                # waypoint = waypoints_sequence.pop(0)
                if self.waypoint[0] == "radish":
                    self.radish_waypoint.getField("translation").setSFVec3f(self.waypoint[1])
                    last_translation = self.radish_waypoint.getField("translation")
                elif self.waypoint[0] == "pumpkin":
                    self.pumpkin_waypoint.getField("translation").setSFVec3f(self.waypoint[1])
                    last_translation = self.pumpkin_waypoint.getField("translation")
                elif self.waypoint[0] == "carrot":
                    self.carrot_waypoint.getField("translation").setSFVec3f(self.waypoint[1])
                    last_translation = self.carrot_waypoint.getField("translation")

                if self.check_waypoint_reached(waypoint_location=self.waypoint[1]):
                    self.status = "drop"
                    last_translation.setSFVec3f([0.0, 0.0, 10])  # Reset the waypoint position
                    print(f"Picked {self.waypoint[0]}, now dropping it.")
                    self.collected[self.waypoint[0]] += 1

            elif self.status == "drop":
                self.drop_waypoint.getField("translation").setSFVec3f(self.waypoint[2])
                last_translation = self.drop_waypoint.getField("translation")

                if self.check_waypoint_reached(waypoint_location=self.waypoint[2]):
                    print(f"Dropped {self.waypoint[0]}, moving to next vegetable.")
                    self.status = "pick"
                    self.dropped[self.waypoint[0]] += 1
                    last_translation.setSFVec3f([0.0, 0.0, 10])  # Reset the waypoint position
                    if waypoints_sequence:
                        self.waypoint = waypoints_sequence.pop(0)
                    else:
                        self.update_robot_info(LABEL_ID=1)
                        print("All vegetables completed.")
                        self.run_completed = True
        else:
            self.save_coordinates_file(self.robot_position_time)
            self.save_zip_file()
            return False
                
        return True



