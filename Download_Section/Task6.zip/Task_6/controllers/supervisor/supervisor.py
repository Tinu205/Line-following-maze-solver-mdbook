from controller import Supervisor, Robot # type: ignore 
import requests
import json

from supervisor_module import (
	Supervisor_Controller
	)

supervisor = Supervisor()

supervisor_controller = Supervisor_Controller(supervisor) 

while not supervisor.step(32) == -1:
	if not supervisor_controller.check_and_update():
		break

supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)