from controller import Supervisor  # type: ignore
import json
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP
from zipfile import ZipFile
import random
import math
import sys

LABEL_ID_TIME = 0
LABEL_ID_ORDER = 1
LABEL_ID_GATE = 2


class Supervisor_Controller:
    """
    A controller class for managing a Webots simulation supervisor that handles robot navigation through colored gates.
    
    This class manages the simulation environment including gate colors, object placement, collision detection,
    and coordinates the robot's progression through a sequence of colored gates in a specific order.
    """
    
    def __init__(self, supervisor):
        """
        Initialize the Supervisor Controller with all necessary components.
        
        Args:
            supervisor: The Webots Supervisor instance for controlling the simulation
        """
        print("Supervisor Running!")
        self.supervisor = supervisor
        self.timestep = int(self.supervisor.getBasicTimeStep())
        self.time = 0
        self.remaining_time = 60 - self.time
        self.get_robot_fields()
        self.get_team_info()
        self.team_id = self.team_info['team_id']
        self.coordinates = {}
        self.color_list = [
            {"name": "red", "rgb": [0.647, 0.1137, 0.1764]},
            {"name": "yellow", "rgb": [0.898, 0.647, 0.0392]},
            {"name": "purple", "rgb": [0.38039, 0.2078, 0.5137]},
        ]
        self.color_order_to_follow = ["purple", "red", "yellow"]
        self.gates = self.initialize_gates()
        # self.epuck = self.supervisor.getFromDef("EPUCK")
        self.gate_color_mapping = {}
        self.bridges = {
            "bridge1": self.supervisor.getFromDef("BRIDGE1"),
            "bridge2": self.supervisor.getFromDef("BRIDGE2"),
        }
        self.breakers = {
            f"breaker{i}": self.supervisor.getFromDef(f"BREAKER{i}")
            for i in range(1, 7)
        }
        self.assign_colors_to_gates()
        self.place_objects()



    def get_robot_fields(self):
        """
        Retrieve and initialize robot field references from the simulation.
        
        Gets the EPUCK robot node and its translation field for position tracking.
        Exits the program if the EPUCK robot is not found in the world file.
        """
        self.epuck = self.supervisor.getFromDef("EPUCK")

        if self.epuck is None:
            sys.stderr.write("No DEF EPUCK node found in the current world file\n")
            sys.exit(1)

        self.translation_field_robot = self.epuck.getField("translation")

    def initialize_gates(self):
        """
        Initialize and retrieve all gate objects from the simulation.
        
        Creates a dictionary mapping gate names to their corresponding Webots node objects.
        Gates are numbered 1-9 and exist on both LEFT and RIGHT sides.
        
        Returns:
            dict: Dictionary with gate names as keys and Webots node objects as values
        """
        return {
            f"{side}_GATE{i}": self.supervisor.getFromDef(f"{side}_GATE{i}")
            for i in range(1, 10)
            for side in ["LEFT", "RIGHT"]
        }

    def set_gate_color(self, gate, rgb_color):
        """
        Set the visual color of a gate in the simulation.
        
        Args:
            gate: The Webots gate node object to modify
            rgb_color (list): RGB color values as a list of three floats [r, g, b]
        """
        if gate is not None:
            shape = gate.getField("children").getMFNode(0)
            appearance = shape.getField("appearance").getSFNode()
            base_color = appearance.getField("baseColor")
            base_color.setSFColor(rgb_color)

    def assign_colors_to_gates(self):
        """
        Randomly assign colors to gates in three groups of three gates each.
        
        Gates 1-3, 4-6, and 7-9 are each assigned the three available colors (red, yellow, purple)
        in random order. Both LEFT and RIGHT gates in each position get the same color.
        Updates the gate_color_mapping dictionary with the assignments.
        """
        for start_index in [1, 4, 7]:
            random.shuffle(self.color_list)
            for i, color in enumerate(self.color_list):
                left_gate_name = f"LEFT_GATE{start_index + i}"
                right_gate_name = f"RIGHT_GATE{start_index + i}"
                left_gate = self.gates[left_gate_name]
                right_gate = self.gates[right_gate_name]
                self.set_gate_color(left_gate, color["rgb"])
                self.set_gate_color(right_gate, color["rgb"])
                self.gate_color_mapping[left_gate_name] = color["name"]
                self.gate_color_mapping[right_gate_name] = color["name"]

    def place_solid_behind_gate(self, solid, gate_name, offset):
        """
        Position a solid object behind a specified gate with the given offset.
        
        Args:
            solid: The Webots solid object to position
            gate_name (str): Name of the gate to position the object behind
            offset (list): 3D offset values [x, y, z] from the gate position
        """
        gate = self.gates.get(gate_name)
        if gate is not None and solid is not None:
            gate_position = gate.getPosition()
            solid_position = [
                gate_position[0] + offset[0],
                gate_position[1] + offset[1],
                gate_position[2] + offset[2],
            ]
            solid.getField("translation").setSFVec3f(solid_position)

    def place_objects(self):
        """
        Place bridges and breakers behind appropriate gates based on their colors and positions.
        
        - Places bridge1 behind the purple gate in positions 1-3
        - Places bridge2 behind the red gate in positions 4-6  
        - Places breakers 1-6 behind specific colored gates on the LEFT side only
        """
        for gate_name, color in self.gate_color_mapping.items():
            if color == "purple" and "1" <= gate_name[-1] <= "3":
                self.place_solid_behind_gate(self.bridges["bridge1"], gate_name, [0.12, 0.18, -0.03])
                break
        for gate_name, color in self.gate_color_mapping.items():
            if color == "red" and "4" <= gate_name[-1] <= "6":
                self.place_solid_behind_gate(self.bridges["bridge2"], gate_name, [0.12, 0.18, -0.03])
                break
        # Place breakers behind gates based on color and set
        offsets = [0.13, 0.81, -0.1]
        for gate_name, color in self.gate_color_mapping.items():
            if gate_name.startswith("LEFT_GATE"):
                if color == "red" and "1" <= gate_name[-1] <= "3":
                    self.place_solid_behind_gate(self.breakers["breaker1"], gate_name, offsets)
                elif color == "yellow" and "1" <= gate_name[-1] <= "3":
                    self.place_solid_behind_gate(self.breakers["breaker2"], gate_name, offsets)
                elif color == "purple" and "4" <= gate_name[-1] <= "6":
                    self.place_solid_behind_gate(self.breakers["breaker3"], gate_name, offsets)
                elif color == "yellow" and "4" <= gate_name[-1] <= "6":
                    self.place_solid_behind_gate(self.breakers["breaker4"], gate_name, offsets)
                elif color == "purple" and "7" <= gate_name[-1] <= "9":
                    self.place_solid_behind_gate(self.breakers["breaker5"], gate_name, offsets)
                elif color == "red" and "7" <= gate_name[-1] <= "9":
                    self.place_solid_behind_gate(self.breakers["breaker6"], gate_name, offsets)

    def check_collision(self, gate, epuck):
        """
        Check if the robot is close enough to a gate to be considered in collision.
        
        Args:
            gate: The Webots gate node object
            epuck: The Webots robot node object
            
        Returns:
            bool: True if the distance between gate and robot is less than 0.13 units
        """
        gate_position = gate.getPosition()
        epuck_position = epuck.getPosition()
        distance = math.sqrt(
            sum(
                (gate_position[i] - epuck_position[i]) ** 2
                for i in range(3)
            )
        )
        return distance < 0.13
    
    def past_gate_collision(self, gate, epuck):
        """
        Check if the robot has moved past a gate after collision.
        
        Used to determine when the robot has successfully passed through a gate
        and is far enough away to proceed to the next target.
        
        Args:
            gate: The Webots gate node object
            epuck: The Webots robot node object
            
        Returns:
            bool: True if the distance is between 0.12 and 0.15 units (past the gate)
        """
        gate_position = gate.getPosition()
        epuck_position = epuck.getPosition()
        distance = math.sqrt(
            sum(
                (gate_position[i] - epuck_position[i]) ** 2
                for i in range(3)
            )
        )
        print("Distance from gate - ", distance)
        return (0.09 < distance < 0.15)

    def rotate_gate(self, gate, velocity, max_rotation):
        """
        Rotate a gate by a specified velocity up to a maximum rotation angle.
        
        Args:
            gate: The Webots gate node object to rotate
            velocity (float): Rotation velocity (positive or negative)
            max_rotation (float): Maximum rotation angle in radians
            
        Returns:
            bool: True if the gate has reached maximum rotation, False otherwise
        """
        hinge = gate.getField("rotation")
        current_rotation = hinge.getSFRotation()
        new_rotation = current_rotation[:]
        new_rotation[3] += velocity * self.timestep / 1000.0
        if abs(new_rotation[3]) > max_rotation:
            new_rotation[3] = max_rotation if velocity > 0 else -max_rotation
        hinge.setSFRotation(new_rotation)
        return abs(new_rotation[3]) >= max_rotation

    def get_target_gate_positions(self):
        """
        Get the 3D positions of target gates in the correct color sequence.
        
        Finds the positions of gates that match the required color sequence
        (purple, red, yellow) for the robot to navigate through.
        
        Returns:
            list: List of 3D position coordinates for target gates
        """
        # Create a list of target gate positions
        target_gate_positions = []
        for color, gate_range in zip(self.color_order_to_follow, [(1, 3), (4, 6), (7, 9)]):
            for gate_num in range(gate_range[0], gate_range[1] + 1):
                for side in ["LEFT", "RIGHT"]:
                    gate_name = f"{side}_GATE{gate_num}"
                    if self.gate_color_mapping.get(gate_name) == color:
                        gate = self.gates.get(gate_name)
                        if gate is not None:
                            target_gate_positions.append(gate.getPosition())
                            break
                if len(target_gate_positions) == len(self.color_order_to_follow):
                    break
        return target_gate_positions

    def save_coordinates(self):
        """
        Save simulation data including time, gate order, and target positions to files.
        
        Creates two output files:
        1. coordinates.json - Human-readable JSON file containing simulation data
        2. coordinates.bin - Encrypted binary file (commented out) using RSA and AES encryption
        
        The saved data includes:
        - Current simulation time
        - Gate color order to follow (purple, red, yellow)
        - Target gate positions (3D coordinates)
        - Any additional data stored in self.coordinates (like opened_gates)
        
        Note: The binary file creation with encryption is currently commented out but 
        includes RSA public key encryption for session key and AES encryption for data.
        """
        # Add time and gate order to the coordinates dictionary
        self.coordinates["time"] = self.supervisor.getTime()
        self.coordinates["gate_order"] = self.color_order_to_follow

        # Add target gate positions to coordinates
        self.coordinates["target_gate_positions"] = self.get_target_gate_positions()

        # # Save the updated coordinates dictionary to coordinates.json
        # Do this if you wanna check what gets saved ig
        # with open("coordinates.json", "w") as myfile:
        #     json.dump(self.coordinates, myfile, indent=4)
        # Save the updated coordinates dictionary to coordinates.bin
        with open("coordinates.bin", "wb") as myfile:
            public_key = RSA.import_key(open("public.pem").read())
            temp_aes_key = get_random_bytes(16)
            cipher_rsa = PKCS1_OAEP.new(public_key)
            enc_session_key = cipher_rsa.encrypt(temp_aes_key)
            cipher_aes = AES.new(temp_aes_key, AES.MODE_EAX)
            ciphertext, tag = cipher_aes.encrypt_and_digest(
                json.dumps(self.coordinates).encode("utf8")
            )
            [myfile.write(x) for x in (enc_session_key, cipher_aes.nonce, tag, ciphertext)]
        # This bit is for checking if the coordinates get saved before tryna encrypt iit like the above code does.
        # with open("coordinates.bin", "w") as myfile:
        #         json.dump(self.coordinates, myfile)
            
           

    def save_zip(self):
        """
        Create a zip file containing simulation data and robot code.
        
        Packages the following files into a team-specific zip file:
        - coordinates.bin (encrypted simulation data)
        - e-puck.py (robot controller code)
        - team_info.json (team information)
        """
        # Ensure coordinates are saved before zipping
        self.save_coordinates()
        # with ZipFile("simulation_data.zip", "w") as myzip:
        with ZipFile("../../" + self.team_id + "_Task6" + ".zip", "w") as myzip:
            myzip.write("coordinates.bin")
            myzip.write("../e-puck/e-puck.py", "e-puck.py")
            myzip.write("../../teaminfo.json", "team_info.json")
            print("Zipping completed!")

    def get_team_info(self):
        """
        Load team information from the teaminfo.json file.
        
        Reads the team ID from the JSON file and validates it's not the default placeholder.
        Pauses simulation and exits if the file is not found or contains default values.
        
        Raises:
            Exception: If teaminfo.json file is not found
            SystemExit: If team ID is still the default placeholder "IE#1234"
        """
        self.team_info = {} #This would store team info, primarily the team ID after reading it from the JSON file
        try:
            with open('../../teaminfo.json') as team_file:
                self.team_info = json.load(team_file) #Read team information from the file and store it
        except:
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            raise Exception("File not found, please make sure teaminfo.json exists in the parent folder") from None

        self.team_id = self.team_info['team_id']  # Extract the team ID
        print("Team ID:", self.team_id)
        if self.team_id == "IE#1234":
            self.supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
            sys.stderr.write("Please first edit the teaminfo.json file and enter your team ID in place of IE#1234\n")
            sys.exit(1)


    def check_and_update(self):
        """
        Main simulation loop that handles robot navigation through colored gates.
        
        Continuously monitors the simulation for:
        - Time limit (60 seconds)
        - Robot collision with correct/incorrect gates
        - Gate opening sequence based on color order
        - Robot progress through the course
        - Collision detection with obstacles
        
        The simulation ends when:
        - Time limit is reached
        - All gates are successfully navigated
        - Robot collides with wrong gate or obstacle
        """
        current_target_index = 0
        opened_gates = []  # List to store colors of opened gates

        while self.supervisor.step(self.timestep) != -1:
            # Check if the time exceeds 60 seconds
            self.time = self.supervisor.getTime()
            self.remaining_time = 60 - self.time
            time_text = f"{self.remaining_time:5.1f} s"
            self.supervisor.setLabel(LABEL_ID_TIME, "Remaining Time: " + time_text, 0, 0, 0.1, 0x0000000, 0.0, "Arial")
            self.supervisor.setLabel(LABEL_ID_ORDER, "Gate order: Purple-Red-Yellow", 0, 0.05, 0.1, 0x0000000, 0.0, "Arial")
            if self.time > 60:
                print("Time Over. Ending simulation.")
                self.coordinates["opened_gates"] = opened_gates  # Save opened gates
                self.save_coordinates()  # Save updated data
                self.save_zip()  # Zip the data
                return

            # Check if all gates have been processed
            if current_target_index >= len(self.color_order_to_follow):
                print("All gates processed. Exiting...")
                self.coordinates["opened_gates"] = opened_gates  # Save opened gates
                self.save_coordinates()  # Save updated data
                self.save_zip()  # Zip the data
                return

            current_target_color = self.color_order_to_follow[current_target_index]
            # print("Current target color:", current_target_color)
            self.supervisor.setLabel(LABEL_ID_GATE, "Target Gate: " + current_target_color, 0, 0.1, 0.1, 0x0000000, 0.0, "Arial")


            for gate_name, gate in self.gates.items():
                if gate is not None and self.check_collision(gate, self.epuck):
                    gate_color = self.gate_color_mapping.get(gate_name, None)
                    # print("GATE COLOR - ", gate_color)
                    # print("TARGET COLOR - ", current_target_color)

                    gate_index = int(gate_name.split("GATE")[1][0])


                    left_gate_name = f"LEFT_GATE{gate_index}"
                    right_gate_name = f"RIGHT_GATE{gate_index}"

                    if (
                        (gate_name == left_gate_name or gate_name == right_gate_name)
                        and gate_color == current_target_color
                    ):
                        print(f"CORRECT GATE DETECTED: {gate_name} with color {gate_color}")

                        left_gate = self.gates[left_gate_name]
                        right_gate = self.gates[right_gate_name]
                        left_done = self.rotate_gate(left_gate, 1.0, 1.6)
                        right_done = self.rotate_gate(right_gate, -1.0, 1.6)

                        if left_done and right_done:
                            
                            if self.past_gate_collision(gate, self.epuck):
                                current_target_index += 1
                                opened_gates.append(gate_color)  # Append gate color
                                print(f"Gate {gate_name} opened. Color: {gate_color}")
                            else:
                                print("Not far enough away from current gate yet to check next gate")
                        else:
                            print(f"Gate {gate_name} not fully rotated yet.")

                    else:
                        print(f"WRONG GATE: {gate_name} with color {gate_color}")
                        contactPoints = self.supervisor.getFromDef("EPUCK").getContactPoints()
                        for x in contactPoints:
                            if x.point[2] > 0.1:
                                print("COLLISION")
                                self.coordinates["opened_gates"] = opened_gates  # Save opened gates
                                self.save_coordinates()  # Save updated data
                                self.save_zip()  # Zip the data
                                return

            # Check if all gates have been processed
            if current_target_index >= len(self.color_order_to_follow):
                print("SUCCESS")
                self.coordinates["opened_gates"] = opened_gates  # Save opened gates
                self.save_coordinates()  # Save updated data
                self.save_zip()  # Zip the data
                return
            else:
                contactPoints = self.supervisor.getFromDef("EPUCK").getContactPoints()
                for x in contactPoints:
                    if x.point[2] > 0.1:
                        print("Collision with separate object")
                        self.coordinates["opened_gates"] = opened_gates  # Save opened gates
                        self.save_coordinates()  # Save updated data
                        self.save_zip()  # Zip the data
                        return



